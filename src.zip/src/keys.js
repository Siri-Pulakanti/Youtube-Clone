export const API_KEY = "AIzaSyCnS8P6tvzIGJPtVYLQB27WL5JUDdYl6SA";
export default API_KEY;
