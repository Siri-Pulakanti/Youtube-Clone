// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBAeS6jP3OUKnj7zYrbaznmSlU1Z3YMaZE",
  authDomain: "clone-fe24b.firebaseapp.com",
  databaseURL: "https://clone-fe24b.firebaseio.com",
  projectId: "clone-fe24b",
  storageBucket: "clone-fe24b.appspot.com",
  messagingSenderId: "1084195521966",
  appId: "1:1084195521966:web:60092835f178e4dc86b43f",
  measurementId: "G-6Y12BX6K4P",
};
